(function ($) {
    const { BrowserWindow } = require('electron').remote
    const fs = require('fs');
    const jquery = require('jquery');
    const PDFWindow = require('electron-pdf-window');

    $.print = {
        nombre: 'FILE-PROSOFT',
        datos: null,
        formato: null,
        tipo: null,
        extra: null,
        callback: null,

        _init: function (params) {
            this.nombre = params.nombre || this.nombre;
            this.tipo = params.tipo || false;
            this.datos = params.datos || false;
            this.formato = params.formato || false;
            this.extra = params.extra || false;

            if (this.tipo) {
                if (this.tipo.toLowerCase() == 'pdf') this._sendPdf()
                else if (this.tipo.toLowerCase() == 'csv') setTimeout(function () { $.print._sendCsv() }, 100)
                else if (this.tipo.toLowerCase() == 'xls') setTimeout(function () { $.print._sendXls() }, 100)
            } else {
                alert('Debes definir un tipo de impresión')
            }
        },

        _sendXls: function () {
            var dl, fn;
            var elt = document.getElementById(this.maqueta);
            var wb = XLSX.utils.table_to_book(elt, { sheet: this.nombre });
            this._printEnd();
            return dl ?
                XLSX.write(wb, { bookType: 'xlsx', bookSST: true, type: 'base64' }) :
                XLSX.writeFile(wb, fn || (this.nombre + '.xlsx'));
        },

        _sendPdf: function () {
            const ventaPdf = path.join('file://', __dirname, '../pdf/' + this.formato);

            let winPdf = new BrowserWindow({
                width: 800,
                height: 800,
                title: 'Generando pdf',
                webPreferences: {
                    nodeIntegration: true
                },
                show: false
            })

            winPdf.loadURL(ventaPdf)
            winPdf.webContents.on('did-finish-load', () => {
                winPdf.webContents.send('ping', { datos: $.print.datos, extra: $.print.extra })

                setTimeout(function () {
                    winPdf.webContents.printToPDF({}, (error, data) => {
                        if (error) throw error
                        let filePdf = path.join('C:/PROSOFT/TEMP/' + $.print.nombre + '.pdf');
                        fs.writeFile(filePdf, data, (error) => {
                            if (error) throw error
                            winPdf.destroy();
                        })
                    })
                }, 100);
            })

            winPdf.on('closed', () => {
                winPdf = null;
                const win = new BrowserWindow({
                    width: 800,
                    height: 600,
                    autoHideMenuBar: true,
                    webPreferences: {
                        nodeIntegration: true
                    }
                })

                win.maximize()
                PDFWindow.addSupport(win);
                var dir = path.join('C:/PROSOFT/TEMP/' + $.print.nombre + '.pdf');
                win.loadURL(dir)
                win.webContents.on('did-finish-load', function () {
                    $.print._printEnd();
                    let path = 'C:/PROSOFT/TEMP/' + $.print.nombre + '.pdf';
                    setTimeout(function () {
                        fs.unlink(path, (err) => {
                            if (err) {
                                console.error(err)
                                return
                            }
                        })
                    }, 500)
                });
            })

            // winPdf.hide()
        },

        _sendCsv: function () {
            var csv = [];
            var rows = document.querySelectorAll("table tr");
            for (var i = 0; i < rows.length; i++) {
                var row = [], cols = rows[i].querySelectorAll("td, th");

                for (var j = 0; j < cols.length; j++)
                    row.push(cols[j].innerText);

                csv.push(row.join(","));
            }

            this._downloadCsv(csv.join("\n"));
        },

        _downloadCsv: function (csv) {
            var csvFile;
            var downloadLink;
            csvFile = new Blob([csv], { type: "text/csv" });
            downloadLink = document.createElement("a");
            downloadLink.download = this.nombre + '.csv';
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
            downloadLink.click();
            this._printEnd();
        },

        _printEnd: function () {
            // $('#print_config').remove();
            if (this.callback) this.callback(this.callback);
        },

        // _config: function () {
        //     $('head').prepend(''
        //         + "<style id='print_config'>"
        //         + " @import url('https://fonts.googleapis.com/css?family=Roboto:400,500,700');\n"
        //         + " html,\n"
        //         + this.estilo + ",\n"
        //         + this.maqueta + ",\n"
        //         + " body {"
        //         + "     margin: 0 auto;"
        //         + "     padding: 0;"
        //         + "     width: 100%;"
        //         + "     height: 100%;"
        //         + "     font-family: 'Roboto', sans-serif;"
        //         + "     box-sizing: border-box;"
        //         + " }\n"
        //         + "</style>"
        //     )
        // }
    }

    imprimir = function (params, callback) {
        $.print.callback = callback || false;
        $.print._init(params);
    }

})(jQuery);